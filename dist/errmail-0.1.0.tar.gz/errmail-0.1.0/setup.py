"""/**
 * @file setup.py
 * @description Legacy setuptools entry for older environments.
 */"""

from __future__ import annotations

from setuptools import setup

setup()

